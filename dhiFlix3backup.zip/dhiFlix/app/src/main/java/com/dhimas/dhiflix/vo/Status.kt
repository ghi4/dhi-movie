package com.dhimas.dhiflix.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}