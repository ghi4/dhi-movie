package com.dhimas.dhiflix.data.source.remote

enum class StatusResponse {
    SUCCESS,
    ERROR,
    EMPTY
}